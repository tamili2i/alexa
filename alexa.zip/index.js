/**
 *
 */

'use strict';
const Alexa = require('alexa-sdk');
const Patient = require('./app/PatientModule.js');
const Appointment = require('./app/Appointment.js');

//console.log('======================', patient);
// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.
const handlers = {
    'BookAppointment': function () {
        var self = this;

        Appointment.createAppointment(self);
    }, 
    'LaunchRequest': function() {
        var self = this;
        self.emit(":ask", "Welcome to ideamed, how can I help you");
    },
    'GetAppointmentList': function() {
        var self = this;
        Appointment.getAppointments(self);
    }
};

exports.handler = function(event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.appId = process.env.APP_ID; // APP_ID is your skill id which can be found in the Amazon developer console where you create the skill.
    alexa.registerHandlers(handlers);
    alexa.execute();
};


/**
 * Called when the user invokes the skill without specifying what they want.
 */
function welcomeNote(self) {
    var cardTitle = "Ideamed"
    var speechOutput = "Hi, i am ideamed I can create and list appoinments for you."
    //callback(session.attributes,
      //  buildSpeechletResponse(cardTitle, speechOutput, "", true));
    self.emit(":tell", speechOutput);
}

